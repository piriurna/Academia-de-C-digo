package com.altran.chat.model.chat;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.altran.chat.DBConnector;
import com.altran.chat.model.message.Message;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

public class ChatDAO {

	private static DBConnector dbConnector = DBConnector.getConnector();
	
	public static boolean sendMessage(String message) {
		Connection conn = null;
		boolean sent = false;
		String sql = "call INSERT_MESSAGE(?)";
		try {
			conn = dbConnector.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try(CallableStatement stat = conn.prepareCall(sql)){			
			stat.setString(1, message);
			
			stat.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return sent;
	}
	
	public static ArrayList<Message> getAllMessages() {
		ArrayList<Message> messages = new ArrayList<>();
		Connection conn = null;
		try {
			conn = dbConnector.getConnection();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		String sql = "{ ? = call GetAllMessages }";
		try (CallableStatement cstmt = conn.prepareCall(sql)){
			//Registra o parametro de saida como um cursor
			cstmt.registerOutParameter(1, OracleTypes.CURSOR);
			cstmt.execute();
			//Depois de enviar a query busca o cursor e guarda no result set
			rs = (ResultSet) ((OracleCallableStatement) cstmt).getCursor(1);
			//Percorre todas as linhas do result e gaurda na lista
			while (rs.next()) {
				int id = rs.getInt(1);
				String username = rs.getString(2);
				String message = rs.getString(3);
				messages.add(new Message(id, username, message));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return messages;
	}
}
