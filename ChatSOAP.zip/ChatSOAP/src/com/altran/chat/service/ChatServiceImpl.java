package com.altran.chat.service;

import com.altran.chat.model.chat.ChatDAO;
import com.altran.chat.model.message.Message;

public class ChatServiceImpl implements ChatService {
	@Override
	public void sendMessage(String message) {
		ChatDAO.sendMessage(message);
		System.out.println(message);
	}

	@Override
	public Message[] getMessages() {
		Message[] mList = new Message[ChatDAO.getAllMessages().size()];
		int i = 0;
		for (Message m : ChatDAO.getAllMessages()) {
			mList[i] = m;			
			i++;
		}

		
		System.out.println("Chamado");
		return mList;
	}
}
