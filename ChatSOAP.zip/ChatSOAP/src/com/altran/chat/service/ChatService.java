package com.altran.chat.service;

import com.altran.chat.model.message.Message;

public interface ChatService{

	public void sendMessage(String message);
	
	public Message[] getMessages();
}
