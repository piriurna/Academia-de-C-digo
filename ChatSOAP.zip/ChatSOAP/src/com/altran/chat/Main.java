package com.altran.chat;

import com.altran.chat.model.chat.ChatDAO;

public class Main {

//	public static void main(String[] args) {
//		System.out.println(ChatDAO.getAllMessages());
//	}
}
